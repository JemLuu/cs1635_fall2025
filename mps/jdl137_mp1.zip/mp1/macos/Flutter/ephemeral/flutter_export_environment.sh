#!/bin/sh
# This is a generated file; do not edit or check into version control.
export "FLUTTER_ROOT=/Users/jeremyluu/Documents/Pitt/Spring 2025/CS 1635/flutter"
export "FLUTTER_APPLICATION_PATH=/Users/jeremyluu/Documents/Pitt/Spring 2025/CS 1635/p1/mp1"
export "COCOAPODS_PARALLEL_CODE_SIGN=true"
export "FLUTTER_BUILD_DIR=build"
export "FLUTTER_BUILD_NAME=1.0.2"
export "FLUTTER_BUILD_NUMBER=3"
export "DART_OBFUSCATION=false"
export "TRACK_WIDGET_CREATION=true"
export "TREE_SHAKE_ICONS=false"
export "PACKAGE_CONFIG=.dart_tool/package_config.json"
